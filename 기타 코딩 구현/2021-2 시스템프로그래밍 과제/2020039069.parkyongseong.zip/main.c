#include <stdio.h>
#include <stdlib.h>

int func2(int a, int b)
{
	if (a > b)
		return 0;
	else
		return 1;
}
void func1(int *a, int *b)
{
	int tmp;

	tmp = *a;
	*a = *b;
	*b = tmp;
}

int main(int argc, char *argv[])
{
	int arr[] = {1, 9, 5, 6, 3, 2, 9, 4, 1, 3};

	// Sort arr using bubble sort algorithm
	// YOU MUST USE func1, func2

	// Output MUST be
	// 1 1 2 3 3 4 5 6 9 9

	// fill your own codes from here

	// Bubble Sort
	int len = sizeof(arr) / sizeof(int);
	
	int i, j;

	for (i = 0; i < len - 1; i++)
	{
		for (j = 0; j < len - 1 - i; j++)
		{
			if (!(func2(arr[j], arr[j + 1])))
				func1(&arr[j], &arr[j + 1]);
		}
	}

	// Print
	for (i = 0; i < len; i++)
		printf("%d ", arr[i]);

	return 0;
}
